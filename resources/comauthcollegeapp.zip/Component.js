sap.ui.define(["sap/ovp/app/Component"],function(e){"use strict";return e.extend("com.auth.collegeapp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map
sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("com.auth.collegeapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);